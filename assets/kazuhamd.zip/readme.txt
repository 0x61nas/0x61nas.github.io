﻿=== kazuha Cursor Set ===

By: ツ Mimi Destino ♡ (http://www.rw-designer.com/user/38152) mlopez166@hotmail.com

Download: http://www.rw-designer.com/cursor-set/kazuhamd

Author's description:

.
-

= READ THE DESCRIPTION PLEASE =
Attribution+NonCommercial (CC by-nc)

This cursor's it's don't for sell and please dont re-upload them without credit or my permission, thanks you.
  
 
 ツ MIMI DESTINO ♥.♡ 

Enjoy the set.
Thanks for download and review ✫✫✫✫✫
--

i do this cursors set for a request :)

kazuha of genshin impact 

Diona
http://www.rw-designer.com/cursor-set/dionamd

--

How to install?

without voice
https://youtu.be/-F9ku2X63_g

How to get cute mouse cursors │FREE│  
https://youtu.be/LaPcuFN_WF8

see this video with voice
https://youtu.be/VOr3HZHS4fQ

---

Como instalarlos?
https://youtu.be/EGx6plXI0Yc

--

Have any cursor requests? feel free to comment here -->  http://www.rw-designer.com/entry/3308

social networks --> http://www.rw-designer.com/entry/3309

Discord:  https://discord.gg/xATjrHDPm5
MimiDestino#8426

= Are you going to enter a set of cursors or icons in this month's theme contest? =

http://www.rw-designer.com/forum/6239
--------------------------------------------

 cREDITS https://www.google.com/search?q=kazuha+sword+png&sxsrf=ALiCzsacAK_hW__zB5Fi2w3HEkU7OS-BYg:1651831851699&source=lnms&tbm=isch&sa=X&ved=2ahUKEwi-_f6V0cr3AhVWJEQIHS7KBXcQ_AUoAXoECAEQAw&biw=1920&bih=872 AND https://www.google.com/search?q=kazuha+genshin+impact+png&tbm=isch&ved=2ahUKEwi5wNeRzMr3AhUHDd8KHcArDgwQ2-cCegQIABAA&oq=kazuha+genshin+impact+png&gs_lcp=CgNpbWcQAzIFCAAQgAQyBAgAEB4yBggAEAUQHjoHCCMQ7wMQJzoECAAQQ1CcA1jEDmD-EWgAcAB4AIABzQGIAasGkgEFMC40LjGYAQCgAQGqAQtnd3Mtd2l6LWltZ8ABAQ&sclient=img&ei=5O50Yrm-HYea_AbA17hg&rlz=1C1JZAP_esPR948PR948
     
 Base:  http://www.rw-designer.com/cursor-set/pinkiest-heart-cake-md
 http://www.rw-designer.com/cursor-set/donutskawaiimd
 http://www.rw-designer.com/cursor-set/uldonutskawaiimd

IF YOU SEE MY CURSORS OR BASE ON ANY PAGE INCLUDE HERE PLEASE TELL ME

IF YOU USE MY WORK WITHOUT MY PERMISSION OR YOU DONT CREDIT ME FOR THE CURSORS OR BASE 
THAT'S BAD ... 
read the licence - Attribution+NonCommercial (CC by-nc)
 

==========

License: Creative Commons - Attribution + Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Noncommercial - You may not use this work for commercial purposes.